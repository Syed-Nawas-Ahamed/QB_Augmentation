﻿using System;
using System.Collections.Generic;
using NUnit.Framework;
using System.Reflection;
using GenericBillingSystem.Models;
using System.Web.Mvc;
using System.Linq;
using System.Collections.Specialized;
using System.Globalization;
using System.ComponentModel.DataAnnotations;

namespace GenericBillingSystem.Tests
{
    [TestFixture]
    public class BillingControllerTest
    {
        Assembly assembly = Assembly.Load("GenericBillingSystem");
        Type BillingControllerClass;

        [Test]
        public void Test_IndexMethod_ReturnsLiveProductList()
        {
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            BillingDBContext db = new BillingDBContext();
            try
            {
                BillingControllerClass = assembly.GetType("GenericBillingSystem.Controllers.BillingController");
                if (BillingControllerClass != null)
                {
                    MethodInfo IndexMethod = BillingControllerClass.GetMethod("Index", allBindings);
                    Assert.IsNotNull(IndexMethod, "Action 'Index' NOT implemented OR check spelling");
                    Assert.AreEqual(typeof(ActionResult), IndexMethod.ReturnType, "Action 'Index' return type MUST be 'ActionResult'");

                    ConstructorInfo classConstructor = BillingControllerClass.GetConstructor(Type.EmptyTypes);
                    object BillingControllerclassObject = classConstructor.Invoke(new object[] { });

                    var viewResult = (ViewResult)IndexMethod.Invoke(BillingControllerclassObject, new object[] { });
                    var productslist = (IEnumerable<GenericBillingSystem.Models.Product>)viewResult.ViewData.Model;

                    int productscount = db.Products.Where(x => x.Status == ProductStatus.Live).Count();
                    Assert.AreEqual(productslist.Count(), productscount);
                }
                else
                    Assert.Fail("No class with the name 'BillingController' is implemented OR Did you change the class name");
            }
            catch (Exception ex)
            {
                Assert.Fail("Exception should not be thrown. Please check the application logic");
            }
        }

        [Test]
        public void Test_ListBySearchMethod_ReturnsSearchedLiveProductList()
        {
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            BillingDBContext db = new BillingDBContext();
            try
            {
                BillingControllerClass = assembly.GetType("GenericBillingSystem.Controllers.BillingController");
                if (BillingControllerClass != null)
                {
                    MethodInfo ListBySearchMethod = BillingControllerClass.GetMethod("ListBySearch", allBindings);
                    Assert.IsNotNull(ListBySearchMethod, "Action 'ListBySearch' NOT implemented OR check spelling");
                    Assert.AreEqual(typeof(ActionResult), ListBySearchMethod.ReturnType, "Action 'Index' return type MUST be 'ActionResult'");

                    ConstructorInfo classConstructor = BillingControllerClass.GetConstructor(Type.EmptyTypes);
                    object BillingControllerclassObject = classConstructor.Invoke(new object[] { });

                    Product firstproduct = db.Products.Where(x => x.Status == ProductStatus.Live).FirstOrDefault();
                    string productSearch = "";
                    if (firstproduct != null)
                    {
                        productSearch = firstproduct.ProdName;
                    }

                    var viewResult = (ViewResult)ListBySearchMethod.Invoke(BillingControllerclassObject, new object[] { productSearch });
                    var productslist = (IEnumerable<GenericBillingSystem.Models.Product>)viewResult.ViewData.Model;

                    int productscount = db.Products.Where(x => x.Status == ProductStatus.Live && x.ProdName.Contains(productSearch)).Count();
                    Assert.AreEqual(productslist.Count(), productscount);
                }
                else
                    Assert.Fail("No class with the name 'BillingController' is implemented OR Did you change the class name");
            }
            catch (Exception ex)
            {
                Assert.Fail("Exception should not be thrown. Please check the application logic");
            }
        }

    }
}
