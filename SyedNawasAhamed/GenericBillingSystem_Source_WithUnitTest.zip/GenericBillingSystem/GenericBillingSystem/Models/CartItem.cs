﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace GenericBillingSystem.Models
{
    [NotMapped]
    public class CartItem
    {
        [Key]
        public int ProductCode { get; set; }
        public string ProdName { get; set; }
        public string Units { get; set; }
        public float Price { get; set; }
        public int Quantity { get; set; }
        public float TotalValue { get; set; }
    }
}