﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace GenericBillingSystem.Models
{
    public enum UnitOfMeasure
    {
        
        Grams,
        Kgs,
        Milli_Litre,
        Litres,
        Pcs,
        Boxes,
        Metre
    }

    public enum ProductStatus
    {
        Live,
        Removed
    }

    public class Product
    {
        [Key]
        public int ProductCode { get; set; }

        [Display(Name = "Product Name")]
        public string ProdName { get; set; }

        [Display(Name = "Unit of Measure")]
        public UnitOfMeasure Units { get; set; }

        [Range(1,5000,ErrorMessage = "Price Should be between 1 and 5000")]
        [Display(Name = "Price")]
        public float Price { get; set; }

        [Display(Name = "Product Status")]

        public ProductStatus Status { get; set; }
    }
}