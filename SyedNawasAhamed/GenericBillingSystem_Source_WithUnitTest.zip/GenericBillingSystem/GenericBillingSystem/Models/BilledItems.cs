﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GenericBillingSystem.Models
{
    public class BilledItem
    {
        [Key]
        [Column(Order = 1)]
        public int BillNumber { get; set; }

        [Key]
        [Column(Order = 2)]
        public int ProductCode { get; set; }

        [Required]
        public int Quantity { get; set; }

        [Required]
        public float SoldPrice {get;set;}

        public virtual Product Product { get; set; }
        public virtual Billing Billing { get; set; }
    }
}