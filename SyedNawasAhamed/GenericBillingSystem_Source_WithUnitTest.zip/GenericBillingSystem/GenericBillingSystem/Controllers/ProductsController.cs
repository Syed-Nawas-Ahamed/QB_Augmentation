﻿using System;
using System.Web;
using System.Collections.Generic;
using System.Web.Mvc;
using System.Linq;
using System.Data.Entity.Migrations;
using GenericBillingSystem.Models;

namespace GenericBillingSystem.Controllers
{
    public class ProductsController : Controller
    {
        public static BillingDBContext db;
        // GET: Products
        public ActionResult Index()
        {
            db = new BillingDBContext();
            ViewBag.Message = "Product List";
            return View(db.Products);
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View(new Product());
        }

        [HttpPost]
        [ActionName("Create")]
        public ActionResult Create_Post(Product Prod)
        {
            db = new BillingDBContext();
            if (ModelState.IsValid)
            {
                db.Products.Add(Prod);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View();
        }

        [HttpGet]
        public ActionResult Details(int id)
        {
            db = new BillingDBContext();
            return View(db.Products.Where(prod => prod.ProductCode == id).FirstOrDefault());
        }

        [HttpGet]
        public ActionResult Edit(int id)
        {
            db = new BillingDBContext();
            return View(db.Products.Where(prod => prod.ProductCode == id).FirstOrDefault());
        }

        [HttpPost]
        [ActionName("Edit")]
        public ActionResult Edit_Post(Product prod)
        {
            if (ModelState.IsValid)
            {
                db = new BillingDBContext();
                db.Products.AddOrUpdate(prod);
                db.SaveChanges();
                return RedirectToAction("Details", new { id = prod.ProductCode });
            }
            return View();
        }

        [HttpGet]
        public ActionResult Delete(int id)
        {
            db = new BillingDBContext();
            return View(db.Products.Where(prod => prod.ProductCode == id).FirstOrDefault());
        }

        [HttpPost]
        [ActionName("Delete")]
        public ActionResult Delete_Post(int id)
        {
            db = new BillingDBContext();
            Product prod = db.Products.Where(x => x.ProductCode == id).FirstOrDefault();
            prod.Status = ProductStatus.Removed;
            db.Products.AddOrUpdate(prod);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}